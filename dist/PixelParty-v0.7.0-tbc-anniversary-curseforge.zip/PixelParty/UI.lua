local ADDON_NAME, PP = ...

local Canvas = PP.Canvas
local Portraits = PP.Portraits

local UI = {}
PP.UI = UI

local CELL = 8                      -- on-screen pixels per canvas cell
local GRID = Canvas.DEFAULT_SIZE * CELL -- 512, the canvas widget edge
local FRAME_W = GRID + 28
-- Canvas bottom edge sits 608px from the frame top; two 22px button rows
-- (y=14 and y=42) plus breathing room need ~74px below it.
local FRAME_H = 682

local SWATCH = 24
-- 6, not the original 8: the row carries the wheel button as a 17th slot
-- and lands back on the same 504px it had with 16 swatches.
local SWATCH_GAP = 6

local GALLERY_ROWS = 8
local PICKER_ROWS = 6
local MEMBER_ROWS = 8
local MAX_UNDO = 20

local CHANNEL_LABELS = {
    AUTO = "Auto",
    GUILD = "Guild",
    PARTY = "Party",
    RAID = "Raid",
    INSTANCE_CHAT = "Instance",
}
local CHANNEL_ORDER = { "AUTO", "GUILD", "PARTY", "RAID" }

-- Right mouse button always means "erase", so every tool has a subtractive
-- twin without doubling the button count.
local TOOLS = {
    { id = "PENCIL", label = "Pencil", tip = "Freehand. Drag to draw; right-drag erases." },
    { id = "LINE",   label = "Line",   tip = "Drag for a straight line." },
    { id = "RECT",   label = "Box",    tip = "Drag for a rectangle. Hold Shift to fill it." },
    { id = "CIRCLE", label = "Circle", tip = "Drag for an ellipse. Hold Shift to fill it." },
    { id = "FILL",   label = "Fill",   tip = "Flood-fill the matching area under the cursor." },
    { id = "PICK",   label = "Pick",   tip = "Pick up the colour under the cursor." },
}
local TOOL_BY_ID = {}
for _, t in ipairs(TOOLS) do
    TOOL_BY_ID[t.id] = t
end

UI.selectedColor = 3 -- black
UI.tool = "PENCIL"
UI.brushSize = 1
UI.zoom = CELL       -- screen pixels per cell
UI.panX, UI.panY = 1, 1 -- top-left visible cell
UI.galleryView = nil -- gallery entry being viewed read-only, or nil
UI.galleryPage = 1
UI.pickerPage = 1
UI.memberPage = 1
UI.undoStack = {}

----------------------------------------------------------------------
-- Static popups
----------------------------------------------------------------------

-- 1.15.7 rebuilt StaticPopup on the retail dialog framework: the edit box now
-- hangs off the dialog as .EditBox behind a :GetEditBox() accessor, and the
-- old lowercase .editBox field is gone. Fall back to the old field so a
-- pre-rework client still works.
local function DialogEditBox(dialog)
    return dialog.GetEditBox and dialog:GetEditBox() or dialog.editBox
end

StaticPopupDialogs["PIXELPARTY_CLEAR"] = {
    text = "Clear portrait '%s'? This clears it for everyone painting it.",
    button1 = YES,
    button2 = NO,
    OnAccept = function()
        PP.Comm:SendClear(Portraits.Active())
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_NEW"] = {
    text = "Name the new portrait:",
    button1 = ACCEPT,
    button2 = CANCEL,
    hasEditBox = true,
    maxLetters = 24,
    OnAccept = function(self)
        UI:CreatePortrait(DialogEditBox(self):GetText())
    end,
    EditBoxOnEnterPressed = function(self)
        local dialog = self:GetParent()
        UI:CreatePortrait(self:GetText())
        dialog:Hide()
    end,
    EditBoxOnEscapePressed = function(self)
        self:GetParent():Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_INVITE_SEND"] = {
    text = "Invite whom to '%s'?",
    button1 = ACCEPT,
    button2 = CANCEL,
    hasEditBox = true,
    maxLetters = 48,
    OnShow = function(self, data)
        if data and data.prefill then
            local editBox = DialogEditBox(self)
            editBox:SetText(data.prefill)
            editBox:HighlightText()
        end
    end,
    OnAccept = function(self)
        UI:SendInvite(DialogEditBox(self):GetText())
    end,
    EditBoxOnEnterPressed = function(self)
        local dialog = self:GetParent()
        UI:SendInvite(self:GetText())
        dialog:Hide()
    end,
    EditBoxOnEscapePressed = function(self)
        self:GetParent():Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_INVITE_RECV"] = {
    text = "%s invites you to paint portrait '%s'. Join?",
    button1 = ACCEPT,
    button2 = DECLINE,
    OnAccept = function(self, data)
        PP.Comm:AcceptInvite(data)
    end,
    timeout = 60,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_UNINVITE"] = {
    text = "Remove %s from this portrait? Their copy is deleted and they can no longer paint it.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        UI:DoUninvite(data.name)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_SAVE"] = {
    text = "Save to gallery as:",
    button1 = ACCEPT,
    button2 = CANCEL,
    hasEditBox = true,
    maxLetters = 24,
    OnShow = function(self)
        local p = Portraits.Active()
        local editBox = DialogEditBox(self)
        editBox:SetText(p and p.name or "")
        editBox:HighlightText()
    end,
    OnAccept = function(self)
        UI:SaveToGallery(DialogEditBox(self):GetText())
    end,
    EditBoxOnEnterPressed = function(self)
        local dialog = self:GetParent()
        UI:SaveToGallery(self:GetText())
        dialog:Hide()
    end,
    EditBoxOnEscapePressed = function(self)
        self:GetParent():Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_GALLERY_DELETE"] = {
    text = "Delete gallery entry '%s'?",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        UI:DeleteGalleryEntry(data.index)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["PIXELPARTY_DELETE_PORTRAIT"] = {
    text = "Remove portrait '%s' from this character? (Other members keep their copies.)",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        if Portraits.Delete(data.id) then
            PP.Print("Portrait removed.")
            UI:UpdateAll()
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

----------------------------------------------------------------------
-- Frame construction
----------------------------------------------------------------------

function UI:EnsureFrame()
    if self.frame then
        return
    end

    self.tool = TOOL_BY_ID[PP.db.tool] and PP.db.tool or "PENCIL"
    self.brushSize = PP.db.brushSize or 1
    self.selectedColor = PP.db.color or self.selectedColor
    -- LayoutViewport re-validates the zoom against the active canvas, so a
    -- stale saved value cannot leave the grid in an impossible state.
    self.zoom = PP.db.zoom or CELL
    self.panX, self.panY = 1, 1

    local f = CreateFrame("Frame", "PixelPartyFrame", UIParent, "BackdropTemplate")
    self.frame = f
    -- CreateFrame returns a shown frame; start hidden so Toggle's first
    -- IsShown() check takes the Show() path and OnShow actually fires.
    f:Hide()
    f:SetSize(FRAME_W, FRAME_H)
    f:SetFrameStrata("MEDIUM")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(frame)
        frame:StopMovingOrSizing()
        local point, _, relPoint, x, y = frame:GetPoint(1)
        PP.db.pos = { point = point, relPoint = relPoint, x = x, y = y }
    end)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })

    local pos = PP.db.pos
    if pos and pos.point then
        f:SetPoint(pos.point, UIParent, pos.relPoint or pos.point, pos.x or 0, pos.y or 0)
    else
        f:SetPoint("CENTER")
    end

    self.title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    self.title:SetPoint("TOP", f, "TOP", 0, -16)

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -6, -6)

    self:BuildToolbar(f)
    self:BuildPalette(f)
    self:BuildCanvas(f)
    self:BuildBottomBars(f)
    self:BuildGalleryPanel(f)
    self:BuildPickerPanel(f)
    self:BuildMembersPanel(f)
    self:BuildColorWheel(f)

    tinsert(UISpecialFrames, "PixelPartyFrame")

    -- The picker floats free of this window, so it has to be re-anchored
    -- whenever the canvas appears or disappears underneath it.
    f:SetScript("OnShow", function()
        if UI.picker:IsShown() then
            UI:AnchorPicker()
        end
        UI:UpdateAll()
        PP.Comm:SendHello(Portraits.Active(), false)
    end)
    f:SetScript("OnHide", function()
        -- Child side panels vanish with the window but stay "shown", and a
        -- shown-but-invisible UISpecialFrames entry makes the next Escape
        -- press close nothing visible instead of opening the game menu.
        -- Hide them for real. The picker floats free on purpose.
        UI.members:Hide()
        UI.wheel:Hide()
        UI.gallery:Hide()
        if UI.picker:IsShown() then
            UI:AnchorPicker()
            UI:RefreshPicker()
        end
    end)
end

local function Tooltip(frame, title, body)
    frame:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(title)
        if body then
            GameTooltip:AddLine(body, 1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    frame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
end

function UI:BuildToolbar(f)
    local bar = CreateFrame("Frame", nil, f)
    bar:SetSize(506, 22)
    bar:SetPoint("TOP", f, "TOP", 0, -38)

    local x = 0
    self.toolBtns = {}
    for _, tool in ipairs(TOOLS) do
        local b = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        b:SetSize(54, 22)
        b:SetPoint("LEFT", bar, "LEFT", x, 0)
        b:SetText(tool.label)
        b:SetScript("OnClick", function()
            UI:SetTool(tool.id)
        end)
        Tooltip(b, tool.label, tool.tip)
        self.toolBtns[tool.id] = b
        x = x + 58
    end

    x = x + 4
    self.sizeBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    self.sizeBtn:SetSize(46, 22)
    self.sizeBtn:SetPoint("LEFT", bar, "LEFT", x, 0)
    self.sizeBtn:SetScript("OnClick", function()
        UI.brushSize = UI.brushSize % 3 + 1
        PP.db.brushSize = UI.brushSize
        UI:UpdateButtons()
    end)
    Tooltip(self.sizeBtn, "Brush size", "Freehand nib width, 1 to 3 cells.")
    x = x + 50

    self.undoBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    self.undoBtn:SetSize(54, 22)
    self.undoBtn:SetPoint("LEFT", bar, "LEFT", x, 0)
    self.undoBtn:SetText("Undo")
    self.undoBtn:SetScript("OnClick", function()
        UI:Undo()
    end)
    Tooltip(self.undoBtn, "Undo", "Repaints what your last action covered. Peers see the repaint like any other strokes.")
    x = x + 58

    self.gridBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    self.gridBtn:SetSize(46, 22)
    self.gridBtn:SetPoint("LEFT", bar, "LEFT", x, 0)
    self.gridBtn:SetText("Grid")
    self.gridBtn:SetScript("OnClick", function()
        PP.db.showGrid = not PP.db.showGrid
        UI:UpdateGrid()
        UI:UpdateButtons()
    end)
    Tooltip(self.gridBtn, "Grid", "Overlay cell guides. Local only.")
end

function UI:SetTool(id)
    if not TOOL_BY_ID[id] then
        return
    end
    self:ClearPreview()
    self.tool = id
    PP.db.tool = id
    self:UpdateButtons()
end

function UI:BuildPalette(f)
    local bar = CreateFrame("Frame", nil, f)
    -- The 16 classic swatches plus the wheel button on the end.
    local slots = Canvas.EXTENDED_BASE + 1
    local barWidth = slots * SWATCH + (slots - 1) * SWATCH_GAP
    bar:SetSize(barWidth, SWATCH)
    bar:SetPoint("TOP", f, "TOP", 0, -66)

    self.rings = {}
    for c = 0, Canvas.EXTENDED_BASE - 1 do
        local btn = CreateFrame("Button", nil, bar)
        btn:SetSize(SWATCH, SWATCH)
        btn:SetPoint("LEFT", bar, "LEFT", c * (SWATCH + SWATCH_GAP), 0)

        local ring = btn:CreateTexture(nil, "BACKGROUND")
        ring:SetPoint("TOPLEFT", -3, 3)
        ring:SetPoint("BOTTOMRIGHT", 3, -3)
        ring:SetColorTexture(1, 0.82, 0)
        ring:Hide()
        self.rings[c] = ring

        local border = btn:CreateTexture(nil, "BORDER")
        border:SetPoint("TOPLEFT", -1, 1)
        border:SetPoint("BOTTOMRIGHT", 1, -1)
        border:SetColorTexture(0, 0, 0)

        local swatch = btn:CreateTexture(nil, "ARTWORK")
        swatch:SetAllPoints(btn)
        local col = Canvas.PALETTE[c]
        swatch:SetColorTexture(col[1], col[2], col[3])

        btn:SetScript("OnClick", function()
            UI:SelectColor(c)
        end)
    end
    self:BuildWheelButton(bar)
    self:SelectColor(self.selectedColor)
end

-- The 17th slot on the palette row: opens the color wheel, and stands in
-- for whichever wheel color is selected, since the row has no swatch of
-- its own for those.
function UI:BuildWheelButton(bar)
    local btn = CreateFrame("Button", nil, bar)
    btn:SetSize(SWATCH, SWATCH)
    btn:SetPoint("LEFT", bar, "LEFT", Canvas.EXTENDED_BASE * (SWATCH + SWATCH_GAP), 0)

    local ring = btn:CreateTexture(nil, "BACKGROUND")
    ring:SetPoint("TOPLEFT", -3, 3)
    ring:SetPoint("BOTTOMRIGHT", 3, -3)
    ring:SetColorTexture(1, 0.82, 0)
    ring:Hide()
    self.wheelBtnRing = ring

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetColorTexture(0, 0, 0)

    -- Four vivid quadrants suggest the wheel; a selected wheel color
    -- replaces them wholesale.
    self.wheelBtnQuads = {}
    -- { hue index, x offset, y offset }; shade 1 below picks the vivid ring.
    local quads = {
        { 0, 0, 0 },   -- red, top left
        { 2, 12, 0 },  -- yellow, top right
        { 8, 0, -12 }, -- blue, bottom left
        { 4, 12, -12 } -- green, bottom right
    }
    for _, q in ipairs(quads) do
        local t = btn:CreateTexture(nil, "ARTWORK")
        t:SetSize(12, 12)
        t:SetPoint("TOPLEFT", btn, "TOPLEFT", q[2], q[3])
        local col = Canvas.PALETTE[Canvas.EXTENDED_BASE + q[1] * Canvas.WHEEL_SHADES + 1]
        t:SetColorTexture(col[1], col[2], col[3])
        self.wheelBtnQuads[#self.wheelBtnQuads + 1] = t
    end

    local swatch = btn:CreateTexture(nil, "OVERLAY")
    swatch:SetAllPoints(btn)
    swatch:Hide()
    self.wheelBtnSwatch = swatch

    btn:SetScript("OnClick", function()
        UI:ToggleColorWheel()
    end)
    Tooltip(btn, "Color wheel",
        "48 more colors. Everyone painting needs Pixel Party 0.7+ to see them; older versions keep showing whatever was painted there before, and cannot sync a canvas that uses them.")
end

function UI:SelectColor(c)
    self.selectedColor = c
    if PP.db then
        PP.db.color = c
    end
    for i, ring in pairs(self.rings) do
        ring:SetShown(i == c)
    end
    self:UpdateWheelButton()
end

-- The wheel button doubles as the selected swatch for wheel colors, and the
-- wheel panel's center previews the current color whatever it is.
function UI:UpdateWheelButton()
    if not self.wheelBtnRing then
        return
    end
    local c = self.selectedColor
    local col = Canvas.PALETTE[c] or Canvas.PALETTE[0]
    local extended = c >= Canvas.EXTENDED_BASE
    self.wheelBtnRing:SetShown(extended)
    self.wheelBtnSwatch:SetShown(extended)
    if extended then
        self.wheelBtnSwatch:SetColorTexture(col[1], col[2], col[3])
    end
    for _, q in ipairs(self.wheelBtnQuads) do
        q:SetShown(not extended)
    end
    if self.wheelCenter then
        self.wheelCenter:SetColorTexture(col[1], col[2], col[3])
    end
end

function UI:BuildCanvas(f)
    local canvas = CreateFrame("Frame", nil, f)
    self.canvas = canvas
    canvas:SetSize(GRID, GRID)
    canvas:SetPoint("TOP", f, "TOP", 0, -96)
    canvas:EnableMouse(true)
    canvas:EnableMouseWheel(true)

    -- Textures are allocated per *visible* slot, not per canvas cell, and the
    -- window they show is moved by panning. A bigger canvas therefore costs
    -- nothing extra to render until you zoom out far enough to see more of it
    -- at once, and the pool only ever grows.
    self.slots = {}
    self:LayoutViewport()

    canvas:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then
            UI:OnCanvasDown(UI.selectedColor)
        elseif button == "RightButton" then
            UI:OnCanvasDown(0)
        elseif button == "MiddleButton" then
            UI:StartPan()
        end
    end)
    canvas:SetScript("OnMouseUp", function()
        UI:OnCanvasUp()
    end)
    canvas:SetScript("OnMouseWheel", function(_, delta)
        UI:StepZoom(delta > 0 and 1 or -1)
    end)
    canvas:SetScript("OnUpdate", function()
        if UI.panDrag then
            if IsMouseButtonDown("MiddleButton") then
                UI:DragPan()
            else
                UI.panDrag = nil
            end
        end
        if not UI.dragging then
            return
        end
        if IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton") then
            UI:OnCanvasDrag()
        else
            UI:OnCanvasUp()
        end
    end)
end

-- Edge length of whatever canvas is on screen: the active portrait's, or the
-- gallery entry's while one is open read-only.
function UI:CurrentSize()
    if self.galleryView then
        return self.galleryView.entry.size or Canvas.DEFAULT_SIZE
    end
    local p = Portraits.Active()
    return (p and p.size) or Canvas.DEFAULT_SIZE
end

-- Position and size the slot textures for the current zoom, growing the pool
-- on demand and parking slots that fall outside the window.
function UI:LayoutViewport()
    if not self.canvas then
        return
    end
    local size = self:CurrentSize()
    local zooms = PP.ZoomList(size, GRID)
    local valid = false
    for _, z in ipairs(zooms) do
        if z == self.zoom then
            valid = true
        end
    end
    if not valid then
        self.zoom = zooms[1]
    end

    local n = PP.VisibleCells(size, self.zoom, GRID)
    self.visible = n
    self.panX = PP.ClampPan(size, n, self.panX)
    self.panY = PP.ClampPan(size, n, self.panY)
    -- Repositioning every slot is O(visible^2); UpdateAll runs on every
    -- roster message, so skip the work unless the layout actually changed.
    local key = size .. ":" .. self.zoom
    if self.layoutKey == key then
        return
    end
    self.layoutKey = key
    -- Centre the grid when the canvas does not fill the widget exactly.
    local off = math.floor((GRID - n * self.zoom) / 2)
    self.viewOffset = off

    local reach = math.max(n, self.laidOut or 0)
    for row = 1, reach do
        self.slots[row] = self.slots[row] or {}
        local r = self.slots[row]
        for col = 1, reach do
            if row <= n and col <= n then
                local t = r[col]
                if not t then
                    t = self.canvas:CreateTexture(nil, "ARTWORK")
                    r[col] = t
                end
                t:ClearAllPoints()
                t:SetSize(self.zoom, self.zoom)
                t:SetPoint("TOPLEFT", self.canvas, "TOPLEFT",
                    off + (col - 1) * self.zoom, -(off + (row - 1) * self.zoom))
                t:Show()
            elseif r[col] then
                r[col]:Hide()
            end
        end
    end
    self.laidOut = n
    self:UpdateGrid()
end

-- The texture showing a canvas cell, or nil when it is scrolled out of sight.
function UI:SlotFor(x, y)
    local col, row = PP.CanvasToView(self.panX, self.panY, self.visible or 0, x, y)
    if not col then
        return nil
    end
    local r = self.slots and self.slots[row]
    return r and r[col]
end

function UI:StepZoom(dir)
    if self.galleryView and dir == 0 then
        return
    end
    local size = self:CurrentSize()
    local zooms = PP.ZoomList(size, GRID)
    local idx = 1
    for i, z in ipairs(zooms) do
        if z == self.zoom then
            idx = i
        end
    end
    local target = math.min(#zooms, math.max(1, idx + dir))
    if target == idx then
        return
    end
    -- Keep whatever is under the cursor roughly in view across the change.
    local ax, ay = self:CellFromCursor(true)
    self.zoom = zooms[target]
    PP.db.zoom = self.zoom
    self:LayoutViewport()
    if ax then
        self.panX = PP.ClampPan(size, self.visible, ax - math.floor(self.visible / 2))
        self.panY = PP.ClampPan(size, self.visible, ay - math.floor(self.visible / 2))
    end
    self:RedrawAll()
    self:UpdateButtons()
end

function UI:StartPan()
    if not self.visible or self.visible >= self:CurrentSize() then
        return -- nothing to pan: the whole canvas is on screen
    end
    local scale = self.canvas:GetEffectiveScale()
    local cx, cy = GetCursorPosition()
    self.panDrag = { cx = cx / scale, cy = cy / scale, px = self.panX, py = self.panY }
end

function UI:DragPan()
    local d = self.panDrag
    local scale = self.canvas:GetEffectiveScale()
    local cx, cy = GetCursorPosition()
    cx, cy = cx / scale, cy / scale
    local size = self:CurrentSize()
    -- Grab-the-canvas: dragging right reveals what is to the left. Screen y
    -- grows upward, canvas rows grow downward, hence the flipped signs.
    local nx = PP.ClampPan(size, self.visible, d.px + math.floor((d.cx - cx) / self.zoom + 0.5))
    local ny = PP.ClampPan(size, self.visible, d.py + math.floor((cy - d.cy) / self.zoom + 0.5))
    if nx ~= self.panX or ny ~= self.panY then
        self.panX, self.panY = nx, ny
        self:RedrawAll()
    end
end

-- Guides follow the zoom, so they are repositioned rather than built once.
-- Hairline textures are cheap, but there is no reason to pay for them unasked.
function UI:UpdateGrid()
    if not self.canvas or not self.visible then
        return
    end
    self.gridTex = self.gridTex or {}
    local want = PP.db.showGrid and true or false
    local zoom, off = self.zoom, self.viewOffset or 0
    local span = self.visible * zoom
    local needed = want and (self.visible - 1) or 0
    for i = 1, math.max(needed, self.gridLines or 0) do
        local pair = self.gridTex[i]
        if i <= needed then
            if not pair then
                pair = {
                    v = self.canvas:CreateTexture(nil, "OVERLAY"),
                    h = self.canvas:CreateTexture(nil, "OVERLAY"),
                }
                pair.v:SetColorTexture(0, 0, 0, 0.18)
                pair.h:SetColorTexture(0, 0, 0, 0.18)
                self.gridTex[i] = pair
            end
            pair.v:ClearAllPoints()
            pair.v:SetSize(1, span)
            pair.v:SetPoint("TOPLEFT", self.canvas, "TOPLEFT", off + i * zoom, -off)
            pair.h:ClearAllPoints()
            pair.h:SetSize(span, 1)
            pair.h:SetPoint("TOPLEFT", self.canvas, "TOPLEFT", off, -(off + i * zoom))
            pair.v:Show()
            pair.h:Show()
        elseif pair then
            pair.v:Hide()
            pair.h:Hide()
        end
    end
    self.gridLines = needed
end

----------------------------------------------------------------------
-- Canvas input
----------------------------------------------------------------------

-- `clamp` keeps a shape drag anchored to the canvas edge when the cursor
-- wanders off it, which is how every other pixel editor behaves.
function UI:CellFromCursor(clamp)
    local canvas = self.canvas
    local left, top = canvas:GetLeft(), canvas:GetTop()
    if not left or not top then
        return nil
    end
    local scale = canvas:GetEffectiveScale()
    local cx, cy = GetCursorPosition()
    cx, cy = cx / scale, cy / scale
    local off, zoom, n = self.viewOffset or 0, self.zoom, self.visible or 0
    local col = math.floor((cx - left - off) / zoom) + 1
    local row = math.floor((top - cy - off) / zoom) + 1
    if col < 1 or col > n or row < 1 or row > n then
        if not clamp then
            return nil
        end
        col = math.min(n, math.max(1, col))
        row = math.min(n, math.max(1, row))
    end
    return PP.ViewToCanvas(self.panX, self.panY, col, row)
end

-- Every write to the canvas funnels through here so undo sees all of it.
function UI:Apply(p, x, y, color)
    local size = p.size
    if x < 1 or x > size or y < 1 or y > size then
        return
    end
    local i = Canvas.Index(size, x, y)
    if p.cells[i] == color then
        return
    end
    if self.undoScratch then
        self.undoScratch[#self.undoScratch + 1] = { i, p.cells[i] }
    end
    PP.Comm:Paint(p, x, y, color)
end

function UI:ApplyBrush(p, x, y, color)
    local n = self.brushSize or 1
    if n <= 1 then
        return self:Apply(p, x, y, color)
    end
    local half = math.floor((n - 1) / 2)
    for dy = -half, n - 1 - half do
        for dx = -half, n - 1 - half do
            self:Apply(p, x + dx, y + dy, color)
        end
    end
end

function UI:ActivePaintable()
    if self.galleryView then
        return nil
    end
    local p = Portraits.Active()
    if not p or p.locked then
        return nil
    end
    return p
end

function UI:OnCanvasDown(color)
    local p = self:ActivePaintable()
    if not p then
        return
    end
    local x, y = self:CellFromCursor()
    if not x then
        return
    end
    self.paintColor = color

    if self.tool == "PICK" then
        self:SelectColor(p.cells[Canvas.Index(p.size, x, y)] or 0)
        self:SetTool("PENCIL")
        return
    end

    if self.tool == "FILL" then
        -- Collect the region before painting any of it: the fill walk reads
        -- the same cells the paint would be mutating.
        local region = {}
        Canvas.FloodFill(p.size, p.cells, x, y, function(fx, fy)
            region[#region + 1] = { fx, fy }
        end)
        self.undoScratch = {}
        for _, c in ipairs(region) do
            self:Apply(p, c[1], c[2], color)
        end
        self:PushUndo(p)
        return
    end

    self.dragging = true
    self.anchor = { x, y }
    self.lastCell = nil
    if self.tool == "PENCIL" then
        self.undoScratch = {}
        self:Stroke(p, x, y)
    end
end

function UI:OnCanvasDrag()
    local p = self:ActivePaintable()
    if not p then
        return
    end
    if self.tool == "PENCIL" then
        local x, y = self:CellFromCursor()
        if not x then
            -- Cursor left the canvas mid-drag; restart the stroke when it
            -- returns rather than drawing a line across the gap.
            self.lastCell = nil
            return
        end
        self:Stroke(p, x, y)
    else
        local x, y = self:CellFromCursor(true)
        if x then
            self:PreviewShape(x, y)
        end
    end
end

function UI:OnCanvasUp()
    if not self.dragging then
        return
    end
    self.dragging = false
    local list = self:ClearPreview()
    local p = self:ActivePaintable()
    if p and self.tool ~= "PENCIL" then
        self.undoScratch = {}
        for _, c in ipairs(list) do
            self:Apply(p, c[1], c[2], self.paintColor)
        end
    end
    if p then
        self:PushUndo(p)
    end
    self.undoScratch = nil
    self.lastCell = nil
    self.anchor = nil
end

function UI:Stroke(p, x, y)
    local last = self.lastCell
    if last then
        if last[1] == x and last[2] == y then
            return
        end
        -- Fill in cells a fast drag skipped between two OnUpdate samples.
        local color = self.paintColor
        PP.ForLine(last[1], last[2], x, y, function(px, py)
            UI:ApplyBrush(p, px, py, color)
        end)
    else
        self:ApplyBrush(p, x, y, self.paintColor)
    end
    self.lastCell = { x, y }
end

function UI:ShapeCells(x, y)
    local list = {}
    local a = self.anchor
    if not a then
        return list
    end
    local filled = IsShiftKeyDown()
    local function add(px, py)
        list[#list + 1] = { px, py }
    end
    if self.tool == "LINE" then
        PP.ForLine(a[1], a[2], x, y, add)
    elseif self.tool == "RECT" then
        PP.ForRect(a[1], a[2], x, y, filled, add)
    elseif self.tool == "CIRCLE" then
        PP.ForEllipse(a[1], a[2], x, y, filled, add)
    end
    return list
end

-- Shapes are drawn straight onto the cell textures while dragging and only
-- committed on release, so an in-progress box costs no wire traffic.
function UI:PreviewShape(x, y)
    self:ClearPreview()
    local list = self:ShapeCells(x, y)
    self.previewList = list
    local col = Canvas.PALETTE[self.paintColor] or Canvas.PALETTE[0]
    for _, c in ipairs(list) do
        local t = self:SlotFor(c[1], c[2])
        if t then
            t:SetColorTexture(col[1], col[2], col[3])
        end
    end
end

function UI:ClearPreview()
    local list = self.previewList
    self.previewList = nil
    if not list then
        return {}
    end
    local cells = self:CurrentCells()
    if cells then
        for _, c in ipairs(list) do
            local t = self:SlotFor(c[1], c[2])
            if t then
                local col = Canvas.PALETTE[cells[Canvas.Index(self:CurrentSize(), c[1], c[2])]] or Canvas.PALETTE[0]
                t:SetColorTexture(col[1], col[2], col[3])
            end
        end
    end
    return list
end

----------------------------------------------------------------------
-- Undo (local, and broadcast like any other paint)
----------------------------------------------------------------------

function UI:PushUndo(p)
    local scratch = self.undoScratch
    self.undoScratch = nil
    if not scratch or #scratch == 0 then
        return
    end
    self.undoStack[#self.undoStack + 1] = { pid = p.id, cells = scratch }
    while #self.undoStack > MAX_UNDO do
        table.remove(self.undoStack, 1)
    end
    self:UpdateButtons()
end

function UI:UndoIndex()
    local p = Portraits.Active()
    if not p then
        return nil
    end
    for i = #self.undoStack, 1, -1 do
        if self.undoStack[i].pid == p.id then
            return i
        end
    end
    return nil
end

function UI:Undo()
    local p = self:ActivePaintable()
    if not p then
        return
    end
    local idx = self:UndoIndex()
    if not idx then
        PP.Print("Nothing to undo on '" .. p.name .. "'.")
        return
    end
    local entry = table.remove(self.undoStack, idx)
    -- Newest change first: a cell touched twice in one action must land back
    -- on the colour it had before the action started.
    for i = #entry.cells, 1, -1 do
        local x, y = Canvas.Coords(p.size, entry.cells[i][1])
        PP.Comm:Paint(p, x, y, entry.cells[i][2])
    end
    self:UpdateButtons()
end

----------------------------------------------------------------------
-- Bottom bars
----------------------------------------------------------------------

function UI:BuildBottomBars(f)
    -- Row 1 (y=14): scope/members, status, clear
    local scopeBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    self.scopeBtn = scopeBtn
    scopeBtn:SetSize(110, 22)
    scopeBtn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 14, 14)
    scopeBtn:SetScript("OnClick", function()
        UI:OnScopeClick()
    end)
    scopeBtn:SetScript("OnEnter", function(self)
        local p = Portraits.Active()
        if not p then
            return
        end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if p.dist ~= "MEMBERS" then
            GameTooltip:AddLine("Shared canvas scope")
            GameTooltip:AddLine("Click to cycle Auto / Guild / Party / Raid.", 1, 1, 1, true)
        else
            GameTooltip:AddLine("Members of '" .. p.name .. "'")
            for _, m in ipairs(p.members or {}) do
                local label = Ambiguate(m, "short")
                if Portraits.IsOwner(p, m) then
                    label = label .. " |cff9d9d9d(creator)|r"
                end
                GameTooltip:AddLine(label, 1, 1, 1)
            end
            GameTooltip:AddLine("Click to manage the roster.", 0.6, 0.6, 0.6, true)
        end
        GameTooltip:Show()
    end)
    scopeBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    local zoomBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    self.zoomBtn = zoomBtn
    zoomBtn:SetSize(58, 22)
    zoomBtn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 130, 14)
    zoomBtn:SetScript("OnClick", function()
        -- Cycle inwards, wrapping back to the fit level.
        local zooms = PP.ZoomList(UI:CurrentSize(), GRID)
        if UI.zoom == zooms[#zooms] then
            UI.zoom = zooms[1]
            PP.db.zoom = UI.zoom
            UI:LayoutViewport()
            UI:RedrawAll()
            UI:UpdateButtons()
        else
            UI:StepZoom(1)
        end
    end)
    Tooltip(zoomBtn, "Zoom",
        "Click to step in, or use the mouse wheel over the canvas. Middle-drag pans when the canvas is larger than the window.")

    local clearBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    self.clearBtn = clearBtn
    clearBtn:SetSize(70, 22)
    clearBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -14, 14)
    clearBtn:SetText("Clear")
    clearBtn:SetScript("OnClick", function()
        local p = Portraits.Active()
        if p and not p.locked and not UI.galleryView then
            StaticPopup_Show("PIXELPARTY_CLEAR", p.name)
        end
    end)

    local status = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    self.status = status
    status:SetPoint("BOTTOM", f, "BOTTOM", 0, 19)

    -- Row 2 (y=42): portrait picker, new, invite, lock, save, gallery
    local x = 14
    local function rowBtn(width, label, onClick)
        local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        b:SetSize(width, 22)
        b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", x, 42)
        x = x + width + 6
        if label then
            b:SetText(label)
        end
        b:SetScript("OnClick", onClick)
        return b
    end

    self.portraitBtn = rowBtn(150, nil, function()
        UI:TogglePicker()
    end)
    Tooltip(self.portraitBtn, "Portraits", "Pick which canvas you are painting.")
    self.newBtn = rowBtn(50, "New", function()
        StaticPopup_Show("PIXELPARTY_NEW")
    end)
    self.inviteBtn = rowBtn(60, "Invite", function()
        UI:OnInviteClick()
    end)
    -- A disabled button cannot be clicked, so the chat message explaining why
    -- it is disabled never reaches the person who needs it. Keep the mouse
    -- scripts alive while disabled and say it in the tooltip instead.
    self.inviteBtn:SetMotionScriptsWhileDisabled(true)
    self.inviteBtn:SetScript("OnEnter", function(btn)
        local p = Portraits.Active()
        GameTooltip:SetOwner(btn, "ANCHOR_TOP")
        GameTooltip:AddLine("Invite")
        if UI.galleryView then
            GameTooltip:AddLine("Not while viewing a saved piece - go back to painting first.",
                1, 1, 1, true)
        elseif p and p.dist ~= "MEMBERS" then
            GameTooltip:AddLine("The Shared canvas has no roster: everyone in your scope already paints it. Use New to create a portrait you can invite people to.",
                1, 1, 1, true)
        else
            GameTooltip:AddLine("Whisper an invitation. Prefills a friendly target if you have one.",
                1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    self.inviteBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    self.lockBtn = rowBtn(62, "Lock", function()
        UI:OnLockClick()
    end)
    self.lockBtn:SetMotionScriptsWhileDisabled(true)
    self.lockBtn:SetScript("OnEnter", function(btn)
        local p = Portraits.Active()
        GameTooltip:SetOwner(btn, "ANCHOR_TOP")
        GameTooltip:AddLine(p and p.locked and "Unlock" or "Lock")
        if p and not Portraits.IsOwner(p, PP.PlayerFullName()) then
            GameTooltip:AddLine("Only the portrait's creator can lock or unlock it.", 1, 1, 1, true)
        else
            GameTooltip:AddLine("Freezes the portrait for everyone: no painting, no clearing, until you unlock it. Inviting still works, which is how you share finished art.",
                1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    self.lockBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    self.saveBtn = rowBtn(50, "Save", function()
        if not UI.galleryView then
            StaticPopup_Show("PIXELPARTY_SAVE")
        end
    end)
    self.galleryBtn = rowBtn(64, "Gallery", function()
        UI:ToggleGallery()
    end)
end

----------------------------------------------------------------------
-- Side panels
----------------------------------------------------------------------

-- side "FLOAT" makes the panel a sibling of the main window rather than a
-- child, so it can stand on its own when the canvas is closed. Its position
-- is set by the caller.
local function BuildPanel(f, globalName, titleText, w, h, side)
    local float = side == "FLOAT"
    local g = CreateFrame("Frame", globalName, float and UIParent or f, "BackdropTemplate")
    g:Hide()
    g:SetSize(w, h)
    if float then
        -- HIGH, not DIALOG: above the canvas window, but still below the
        -- StaticPopups this panel opens.
        g:SetFrameStrata("HIGH")
        g:SetClampedToScreen(true)
    elseif side == "LEFT" then
        g:SetPoint("TOPRIGHT", f, "TOPLEFT", 8, 0)
    else
        g:SetPoint("TOPLEFT", f, "TOPRIGHT", -8, 0)
    end
    g:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })

    g.title = g:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    g.title:SetPoint("TOP", g, "TOP", 0, -16)
    g.title:SetText(titleText)

    local close = CreateFrame("Button", nil, g, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", g, "TOPRIGHT", -6, -6)

    tinsert(UISpecialFrames, globalName)
    return g
end

local function BuildPager(g, onChange)
    local text = g:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    text:SetPoint("BOTTOM", g, "BOTTOM", 0, 70)

    local prev = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    prev:SetSize(50, 20)
    prev:SetPoint("BOTTOMLEFT", g, "BOTTOMLEFT", 16, 16)
    prev:SetText("<")
    prev:SetScript("OnClick", function()
        onChange(-1)
    end)

    local next = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    next:SetSize(50, 20)
    next:SetPoint("BOTTOMRIGHT", g, "BOTTOMRIGHT", -16, 16)
    next:SetText(">")
    next:SetScript("OnClick", function()
        onChange(1)
    end)
    return text
end

----------------------------------------------------------------------
-- Gallery panel
----------------------------------------------------------------------

function UI:BuildGalleryPanel(f)
    -- Taller than the other panels: 8 rows plus the pager plus the Back
    -- control, which only appears while an entry is open read-only.
    local g = BuildPanel(f, "PixelPartyGalleryFrame", "Gallery", 300, 500, "RIGHT")
    self.gallery = g

    g:SetScript("OnHide", function()
        -- Closing the gallery returns the canvas to the live portrait.
        if UI.galleryView then
            UI.galleryView = nil
            UI:UpdateAll()
        end
    end)

    self.galleryRows = {}
    for i = 1, GALLERY_ROWS do
        local row = CreateFrame("Frame", nil, g)
        row:SetSize(260, 44)
        row:SetPoint("TOPLEFT", g, "TOPLEFT", 18, -34 - (i - 1) * 46)

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -2)
        row.text:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        row.text:SetJustifyH("LEFT")

        row.viewBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.viewBtn:SetSize(52, 18)
        row.viewBtn:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 0, 2)
        row.viewBtn:SetText("View")

        row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.delBtn:SetSize(52, 18)
        row.delBtn:SetPoint("LEFT", row.viewBtn, "RIGHT", 6, 0)
        row.delBtn:SetText("Del")

        self.galleryRows[i] = row
    end

    self.galleryPageText = BuildPager(g, function(delta)
        UI.galleryPage = math.max(1, UI.galleryPage + delta)
        UI:RefreshGallery()
    end)

    -- Explicit way out of read-only viewing, without closing the panel.
    self.galleryBackBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    self.galleryBackBtn:SetSize(120, 22)
    self.galleryBackBtn:SetPoint("BOTTOM", g, "BOTTOM", 0, 42)
    self.galleryBackBtn:SetText("Back to painting")
    self.galleryBackBtn:Hide()
    self.galleryBackBtn:SetScript("OnClick", function()
        UI.galleryView = nil
        UI:UpdateAll()
    end)
end

function UI:ToggleGallery()
    if self.gallery:IsShown() then
        self.gallery:Hide()
    else
        self.galleryPage = 1
        self.gallery:Show()
        self:RefreshGallery()
    end
end

function UI:RefreshGallery()
    if not self.gallery or not self.gallery:IsShown() then
        return
    end
    local entries = PP.db.gallery
    local pages = math.max(1, math.ceil(#entries / GALLERY_ROWS))
    if self.galleryPage > pages then
        self.galleryPage = pages
    end
    local page = self.galleryPage
    for i = 1, GALLERY_ROWS do
        local row = self.galleryRows[i]
        local index = (page - 1) * GALLERY_ROWS + i
        local entry = entries[index]
        if entry then
            row:Show()
            local when = date("%b %d %H:%M", entry.savedAt or 0)
            row.text:SetText(("%s  |cff9d9d9d(%s)|r"):format(entry.name, when))
            row.viewBtn:SetScript("OnClick", function()
                UI.galleryView = { entry = entry, index = index }
                UI:UpdateAll()
            end)
            row.delBtn:SetScript("OnClick", function()
                StaticPopup_Show("PIXELPARTY_GALLERY_DELETE", entry.name, nil, { index = index })
            end)
        else
            row:Hide()
        end
    end
    self.galleryPageText:SetText(("Page %d / %d  -  %d saved"):format(page, pages, #entries))
    self.galleryBackBtn:SetShown(self.galleryView ~= nil)
end

function UI:SaveToGallery(name)
    local p = Portraits.Active()
    if not p then
        return
    end
    local entry = Portraits.SaveToGallery(p, name)
    PP.Print("Saved '" .. entry.name .. "' to your gallery.")
    self:RefreshGallery()
end

function UI:DeleteGalleryEntry(index)
    if self.galleryView and self.galleryView.index == index then
        self.galleryView = nil
    end
    Portraits.DeleteGalleryEntry(index)
    self:RefreshGallery()
    self:UpdateAll()
end

----------------------------------------------------------------------
-- Portrait picker panel
----------------------------------------------------------------------

function UI:BuildPickerPanel(f)
    -- Floating: this is also what the minimap button opens, and it has to
    -- work as a launcher with the canvas window closed.
    local g = BuildPanel(f, "PixelPartyPortraitsFrame", "Portraits", 300, 440, "FLOAT")
    self.picker = g

    self.pickerRows = {}
    for i = 1, PICKER_ROWS do
        local row = CreateFrame("Button", nil, g)
        row:SetSize(264, 44)
        row:SetPoint("TOPLEFT", g, "TOPLEFT", 18, -34 - (i - 1) * 46)

        row.highlight = row:CreateTexture(nil, "BACKGROUND")
        row.highlight:SetAllPoints(row)
        row.highlight:SetColorTexture(0.5, 0.65, 0.85, 0.22)
        row.highlight:Hide()

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -2)
        row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
        row.text:SetJustifyH("LEFT")

        row.sub = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        row.sub:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 2, 5)
        row.sub:SetJustifyH("LEFT")

        row.openBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.openBtn:SetSize(56, 18)
        row.openBtn:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -62, 2)
        row.openBtn:SetText("Paint")

        row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.delBtn:SetSize(56, 18)
        row.delBtn:SetPoint("LEFT", row.openBtn, "RIGHT", 6, 0)
        row.delBtn:SetText("Remove")

        self.pickerRows[i] = row
    end

    self.pickerPageText = BuildPager(g, function(delta)
        UI.pickerPage = math.max(1, UI.pickerPage + delta)
        UI:RefreshPicker()
    end)

    local canvasBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    canvasBtn:SetSize(150, 22)
    canvasBtn:SetPoint("BOTTOM", g, "BOTTOM", 0, 94)
    canvasBtn:SetText("Open the canvas")
    canvasBtn:SetScript("OnClick", function()
        UI.frame:Show()
    end)
    self.pickerCanvasBtn = canvasBtn

    local newBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    newBtn:SetSize(132, 22)
    newBtn:SetPoint("BOTTOM", g, "BOTTOM", -68, 42)
    newBtn:SetText("New portrait")
    newBtn:SetScript("OnClick", function()
        StaticPopup_Show("PIXELPARTY_NEW")
    end)

    -- Size belongs here rather than in the name popup: StaticPopup's second
    -- button is OnCancel, which also fires on Escape, so a "128" button there
    -- would create canvases when the dialog was dismissed.
    local sizeBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    sizeBtn:SetSize(132, 22)
    sizeBtn:SetPoint("BOTTOM", g, "BOTTOM", -68, 68)
    sizeBtn:SetScript("OnClick", function()
        local sizes = Canvas.SIZES
        local idx = 1
        for i, s in ipairs(sizes) do
            if s == PP.db.newSize then
                idx = i
            end
        end
        PP.db.newSize = sizes[idx % #sizes + 1]
        UI:RefreshPicker()
    end)
    Tooltip(sizeBtn, "Size of the next new portrait",
        "128x128 is four times the area. Everyone painting it needs the same addon version, and a first sync costs proportionally more -- fast between Battle.net friends, slower over whispers.")
    self.pickerSizeBtn = sizeBtn

    local galleryBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    galleryBtn:SetSize(132, 22)
    galleryBtn:SetPoint("BOTTOM", g, "BOTTOM", 68, 42)
    galleryBtn:SetText("Gallery")
    galleryBtn:SetScript("OnClick", function()
        -- Viewing a saved piece renders it into the main canvas grid, so the
        -- gallery only makes sense with the window up.
        UI.frame:Show()
        if not UI.gallery:IsShown() then
            UI:ToggleGallery()
        end
    end)
end

-- Beside the canvas when it is open, centre-screen when it is not.
function UI:AnchorPicker()
    local g = self.picker
    g:ClearAllPoints()
    if self.frame:IsShown() then
        g:SetPoint("TOPRIGHT", self.frame, "TOPLEFT", 8, 0)
    else
        g:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
end

function UI:TogglePicker()
    if self.picker:IsShown() then
        self.picker:Hide()
    else
        self.members:Hide()
        self.wheel:Hide()
        self.pickerPage = 1
        self:AnchorPicker()
        self.picker:Show()
        self:RefreshPicker()
    end
end

function UI:RefreshPicker()
    if not self.picker or not self.picker:IsShown() then
        return
    end
    local list = Portraits.List()
    local pages = math.max(1, math.ceil(#list / PICKER_ROWS))
    if self.pickerPage > pages then
        self.pickerPage = pages
    end
    local page = self.pickerPage
    local activeId = Portraits.Active().id
    for i = 1, PICKER_ROWS do
        local row = self.pickerRows[i]
        local p = list[(page - 1) * PICKER_ROWS + i]
        if p then
            row:Show()
            row.highlight:SetShown(p.id == activeId)
            row.text:SetText(p.name .. (p.locked and "  |cffffcc00(locked)|r" or ""))
            local dims = ("%dx%d"):format(p.size, p.size)
            if p.dist == "MEMBERS" then
                local n = #(p.members or {})
                row.sub:SetText(("%s  -  %d member%s%s"):format(dims, n, n == 1 and "" or "s",
                    Portraits.IsOwner(p, PP.PlayerFullName()) and ", yours" or ""))
            else
                row.sub:SetText(("%s  -  shared, %s"):format(dims, CHANNEL_LABELS[p.dist] or p.dist))
            end
            row.openBtn:SetEnabled(p.id ~= activeId)
            row.openBtn:SetScript("OnClick", function()
                UI:OpenPortrait(p.id)
            end)
            row.delBtn:SetEnabled(p.id ~= Portraits.SHARED_ID)
            row.delBtn:SetScript("OnClick", function()
                StaticPopup_Show("PIXELPARTY_DELETE_PORTRAIT", p.name, nil, { id = p.id })
            end)
        else
            row:Hide()
        end
    end
    self.pickerPageText:SetText(("Page %d / %d  -  %d portrait%s"):format(
        page, pages, #list, #list == 1 and "" or "s"))
    self.pickerSizeBtn:SetText(("New size: %d"):format(PP.db.newSize))
    self.pickerCanvasBtn:SetEnabled(not self.frame:IsShown())
end

function UI:OpenPortrait(id)
    local p = Portraits.Get(id)
    if not p or not Portraits.SetActive(id) then
        return
    end
    self.galleryView = nil
    self.panX, self.panY = 1, 1 -- a different canvas starts at its top-left
    -- Picking a portrait is a request to paint it, including from the
    -- minimap launcher with the canvas closed.
    self.frame:Show()
    self:UpdateAll()
    PP.Comm:SendHello(p, false)
    PP.Print("Now painting '" .. p.name .. "'.")
end

----------------------------------------------------------------------
-- Members panel (uninvite is the creator's alone)
----------------------------------------------------------------------

function UI:BuildMembersPanel(f)
    local g = BuildPanel(f, "PixelPartyMembersFrame", "Members", 300, 410, "LEFT")
    self.members = g

    self.memberRows = {}
    for i = 1, MEMBER_ROWS do
        local row = CreateFrame("Frame", nil, g)
        row:SetSize(264, 26)
        row:SetPoint("TOPLEFT", g, "TOPLEFT", 18, -40 - (i - 1) * 28)

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        row.text:SetPoint("LEFT", row, "LEFT", 2, 0)
        row.text:SetJustifyH("LEFT")

        row.kickBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.kickBtn:SetSize(72, 18)
        row.kickBtn:SetPoint("RIGHT", row, "RIGHT", -2, 0)
        row.kickBtn:SetText("Uninvite")

        self.memberRows[i] = row
    end

    self.memberPageText = BuildPager(g, function(delta)
        UI.memberPage = math.max(1, UI.memberPage + delta)
        UI:RefreshMembers()
    end)

    local inviteBtn = CreateFrame("Button", nil, g, "UIPanelButtonTemplate")
    inviteBtn:SetSize(150, 22)
    inviteBtn:SetPoint("BOTTOM", g, "BOTTOM", 0, 42)
    inviteBtn:SetText("Invite a player")
    inviteBtn:SetScript("OnClick", function()
        UI:OnInviteClick()
    end)
    self.memberInviteBtn = inviteBtn
end

function UI:ToggleMembers()
    local p = Portraits.Active()
    if not p or p.dist ~= "MEMBERS" then
        PP.Print("The Shared canvas has no roster - everyone in your scope already paints it. Create a portrait to invite people.")
        return
    end
    if self.members:IsShown() then
        self.members:Hide()
    else
        self.picker:Hide()
        self.wheel:Hide()
        self.memberPage = 1
        self.members:Show()
        self:RefreshMembers()
    end
end

----------------------------------------------------------------------
-- Color wheel panel
--
-- Deliberately discrete: a continuous HSV disc would offer sixteen million
-- colors and deliver the 48 the wire encoding has room for. Real swatch
-- buttons show exactly what is pickable, hit-test exactly, and need no
-- texture shipped in Media/.
----------------------------------------------------------------------

-- Swatch spacing must clear the WIDEST boxes that can co-exist on
-- neighboring buttons: the golden selection ring (half-extent 10 = 8px
-- half-swatch + 2px inset) against a neighbor's black border (half-extent
-- 9), so neighbors need 19px of clearance on some axis. The tight pairs:
-- adjacent spokes across a diagonal, (2 * 54 * sin 15) / sqrt 2 = 19.8,
-- and adjacent rings on the 30/60-degree spokes, 23 * cos 30 = 19.9.
-- Overlap would not just look clipped — sibling buttons draw in creation
-- order, so a neighbor's border would sit on top of the selection ring.
-- (Ring-vs-ring never co-exists: only one color is selected at a time.)
local WHEEL_SWATCH = 16
local WHEEL_RING_INSET = 2 -- 3px like the palette row would need wider spacing
local WHEEL_RADII = { 54, 77, 100, 123 } -- one radius per shade ring, pale innermost

function UI:BuildColorWheel(f)
    local g = BuildPanel(f, "PixelPartyColorWheelFrame", "Colors", 300, 320, "LEFT")
    self.wheel = g

    -- Wheel origin; swatches hang off it at polar offsets.
    local hub = CreateFrame("Frame", nil, g)
    hub:SetSize(1, 1)
    hub:SetPoint("TOPLEFT", g, "TOPLEFT", 150, -167)

    for hue = 0, Canvas.WHEEL_HUES - 1 do
        -- Red at 12 o'clock, hues clockwise, like a painter's wheel.
        local a = math.rad(hue * (360 / Canvas.WHEEL_HUES))
        for shade = 0, Canvas.WHEEL_SHADES - 1 do
            local c = Canvas.EXTENDED_BASE + hue * Canvas.WHEEL_SHADES + shade
            local r = WHEEL_RADII[shade + 1]
            local btn = CreateFrame("Button", nil, g)
            btn:SetSize(WHEEL_SWATCH, WHEEL_SWATCH)
            btn:SetPoint("CENTER", hub, "CENTER", r * math.sin(a), r * math.cos(a))

            local ring = btn:CreateTexture(nil, "BACKGROUND")
            ring:SetPoint("TOPLEFT", -WHEEL_RING_INSET, WHEEL_RING_INSET)
            ring:SetPoint("BOTTOMRIGHT", WHEEL_RING_INSET, -WHEEL_RING_INSET)
            ring:SetColorTexture(1, 0.82, 0)
            ring:Hide()
            self.rings[c] = ring

            local border = btn:CreateTexture(nil, "BORDER")
            border:SetPoint("TOPLEFT", -1, 1)
            border:SetPoint("BOTTOMRIGHT", 1, -1)
            border:SetColorTexture(0, 0, 0)

            local swatch = btn:CreateTexture(nil, "ARTWORK")
            swatch:SetAllPoints(btn)
            local col = Canvas.PALETTE[c]
            swatch:SetColorTexture(col[1], col[2], col[3])

            btn:SetScript("OnClick", function()
                UI:SelectColor(c)
            end)
        end
    end

    -- Center swatch previews the current color, wherever it came from.
    local border = g:CreateTexture(nil, "BORDER")
    local center = g:CreateTexture(nil, "ARTWORK")
    center:SetSize(30, 30)
    center:SetPoint("CENTER", hub, "CENTER", 0, 0)
    border:SetPoint("TOPLEFT", center, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", center, "BOTTOMRIGHT", 1, -1)
    border:SetColorTexture(0, 0, 0)
    self.wheelCenter = center

    -- The wheel's selection rings did not exist when BuildPalette restored
    -- the saved color; re-select so a saved wheel color shows its ring.
    self:SelectColor(self.selectedColor)
end

function UI:ToggleColorWheel()
    if self.wheel:IsShown() then
        self.wheel:Hide()
    else
        -- The left slot beside the canvas fits one panel at a time.
        self.members:Hide()
        self.picker:Hide()
        self.wheel:Show()
    end
end

function UI:RefreshMembers()
    if not self.members or not self.members:IsShown() then
        return
    end
    local p = Portraits.Active()
    if not p or p.dist ~= "MEMBERS" then
        self.members:Hide()
        return
    end
    local roster = p.members or {}
    local iAmOwner = Portraits.IsOwner(p, PP.PlayerFullName())
    local pages = math.max(1, math.ceil(#roster / MEMBER_ROWS))
    if self.memberPage > pages then
        self.memberPage = pages
    end
    local page = self.memberPage
    self.members.title:SetText("Members of '" .. p.name:sub(1, 18) .. "'")
    for i = 1, MEMBER_ROWS do
        local row = self.memberRows[i]
        local name = roster[(page - 1) * MEMBER_ROWS + i]
        if name then
            row:Show()
            local isOwner = Portraits.IsOwner(p, name)
            local label = Ambiguate(name, "short")
            if isOwner then
                label = label .. "  |cff9d9d9d(creator)|r"
            elseif name == PP.PlayerFullName() then
                label = label .. "  |cff9d9d9d(you)|r"
            end
            row.text:SetText(label)
            -- Only the creator may uninvite, and never themselves.
            row.kickBtn:SetShown(iAmOwner and not isOwner)
            row.kickBtn:SetScript("OnClick", function()
                UI:Uninvite(name)
            end)
        else
            row:Hide()
        end
    end
    local removed = #(p.removed or {})
    self.memberPageText:SetText(("Page %d / %d  -  %d of %d seats%s"):format(
        page, pages, #roster, Portraits.MAX_MEMBERS,
        removed > 0 and ("  -  %d uninvited"):format(removed) or ""))
    self.memberInviteBtn:SetEnabled(#roster < Portraits.MAX_MEMBERS)
end

function UI:Uninvite(name)
    local p = Portraits.Active()
    if not p then
        return
    end
    local full = PP.NormalizeName(name)
    if not full then
        PP.Print("Who should be removed? /pixelparty uninvite <player>")
        return
    end
    if not Portraits.IsOwner(p, PP.PlayerFullName()) then
        PP.Print("Only the portrait's creator can uninvite members.")
        return
    end
    if not Portraits.IsMember(p, full) then
        PP.Print(Ambiguate(full, "short") .. " is not a member of '" .. p.name .. "'.")
        return
    end
    StaticPopup_Show("PIXELPARTY_UNINVITE", Ambiguate(full, "short"), nil, { name = full })
end

function UI:DoUninvite(name)
    local p = Portraits.Active()
    if not p then
        return
    end
    local ok, err = PP.Comm:SendKick(p, name)
    if ok then
        PP.Print("Removed " .. Ambiguate(name, "short") .. " from '" .. p.name .. "'.")
    else
        PP.Print(err or "Could not remove that member.")
    end
end

----------------------------------------------------------------------
-- Button actions
----------------------------------------------------------------------

function UI:CreatePortrait(name)
    name = Portraits.SanitizeName(name)
    if name == "" then
        PP.Print("Give the portrait a name.")
        return
    end
    if Portraits.FindByName(name) then
        PP.Print("You already have a portrait named '" .. name .. "'.")
        return
    end
    local p = Portraits.Create(name, "MEMBERS", nil, PP.PlayerFullName(), PP.db.newSize)
    Portraits.SetActive(p.id)
    self.panX, self.panY = 1, 1
    PP.Print(("Created portrait '%s' (%dx%d). Use Invite to bring in painters."):format(
        p.name, p.size, p.size))
    self:UpdateAll()
end

function UI:OnInviteClick()
    local p = Portraits.Active()
    if not p or p.dist ~= "MEMBERS" then
        PP.Print("The Shared canvas has no roster - everyone in your scope already paints it. Create a portrait to invite people.")
        return
    end
    local prefill = ""
    if UnitIsPlayer("target") and UnitIsFriend("player", "target") then
        prefill = GetUnitName("target", true) or ""
    end
    StaticPopup_Show("PIXELPARTY_INVITE_SEND", p.name, nil, { prefill = prefill })
end

function UI:SendInvite(name)
    local p = Portraits.Active()
    if not p then
        return
    end
    local ok, err = PP.Comm:SendInvite(p, name)
    if ok then
        PP.Print("Invited " .. name .. " to '" .. p.name .. "'.")
    else
        PP.Print(err or "Could not send the invite.")
    end
end

-- `desired` is true/false from the explicit slash verbs; the button passes
-- nil and toggles.
function UI:OnLockClick(desired)
    local p = Portraits.Active()
    if not p then
        return
    end
    if not Portraits.Lockable(p) then
        PP.Print("The Shared canvas cannot be locked - create a portrait for work you want to freeze.")
        return
    end
    if not Portraits.IsOwner(p, PP.PlayerFullName()) then
        PP.Print("Only the portrait's creator can lock or unlock it.")
        return
    end
    if desired == nil then
        desired = not p.locked
    end
    if desired == p.locked then
        PP.Print(("'%s' is already %s."):format(p.name, desired and "locked" or "unlocked"))
        return
    end
    PP.Comm:SendLockState(p, desired)
end

function UI:ShowInvitePopup(data)
    StaticPopup_Show("PIXELPARTY_INVITE_RECV", Ambiguate(data.from, "short"), data.name, data)
end

function UI:OnScopeClick()
    local p = Portraits.Active()
    if p.dist == "MEMBERS" then
        self:ToggleMembers()
        return
    end
    local idx = 1
    for i, mode in ipairs(CHANNEL_ORDER) do
        if mode == p.dist then
            idx = i
            break
        end
    end
    p.dist = CHANNEL_ORDER[idx % #CHANNEL_ORDER + 1]
    self:UpdateButtons()
    self:UpdateStatus()
end

----------------------------------------------------------------------
-- Rendering
----------------------------------------------------------------------

function UI:CurrentCells()
    if self.galleryView then
        return self.galleryView.entry.cells
    end
    local p = Portraits.Active()
    return p and p.cells or nil
end

function UI:UpdateCell(p, x, y)
    if not self.slots or self.galleryView then
        return
    end
    local active = Portraits.Active()
    if not active or active.id ~= p.id then
        return
    end
    local t = self:SlotFor(x, y)
    if not t then
        return -- painted outside the visible window; nothing to repaint
    end
    local col = Canvas.PALETTE[p.cells[Canvas.Index(p.size, x, y)]] or Canvas.PALETTE[0]
    t:SetColorTexture(col[1], col[2], col[3])
end

function UI:RedrawAll()
    if not self.slots or not self.visible then
        return
    end
    local cells = self:CurrentCells()
    if not cells then
        return
    end
    local size = self:CurrentSize()
    for row = 1, self.visible do
        local r = self.slots[row]
        for col = 1, self.visible do
            local t = r and r[col]
            if t then
                local x, y = PP.ViewToCanvas(self.panX, self.panY, col, row)
                local rgb = Canvas.PALETTE[cells[Canvas.Index(size, x, y)]] or Canvas.PALETTE[0]
                t:SetColorTexture(rgb[1], rgb[2], rgb[3])
            end
        end
    end
end

function UI:UpdateStatus()
    if not self.status then
        return
    end
    local p = Portraits.Active()
    if not p then
        return
    end
    if self.galleryView then
        local e = self.galleryView.entry
        self.status:SetText(("Viewing '%s' (saved %s) - read-only"):format(
            e.name, date("%b %d", e.savedAt or 0)))
        return
    end
    local text
    if PP.Comm.sync and PP.Comm.sync.pid == p.id then
        text = "Syncing canvas from " .. Ambiguate(PP.Comm.sync.source, "short") .. "..."
    elseif p.locked then
        text = "|cffffcc00Locked|r by " .. (p.lockedBy and Ambiguate(p.lockedBy, "short") or "owner")
            .. "  -  rev " .. p.rev
    elseif p.dist == "MEMBERS" then
        -- The roster counts us; we whisper to everyone else on it.
        local others = math.max(0, #(p.members or {}) - 1)
        text = ("Whispering %d member%s  -  rev %d"):format(others, others == 1 and "" or "s", p.rev)
    else
        local chatType = PP.Comm:GetScopeChannel(p.dist)
        if chatType then
            text = ("Broadcasting to %s  -  rev %d"):format(CHANNEL_LABELS[chatType] or chatType, p.rev)
        else
            text = ("|cffff6060Offline|r (no %s available)  -  rev %d"):format(
                CHANNEL_LABELS[p.dist] or p.dist, p.rev)
        end
    end
    self.status:SetText(text)
end

function UI:UpdateButtons()
    if not self.frame then
        return
    end
    local p = Portraits.Active()
    if not p then
        return
    end
    local me = PP.PlayerFullName()
    local viewing = self.galleryView ~= nil
    local paintable = not viewing and not p.locked

    self.portraitBtn:SetText("Portrait: " .. p.name:sub(1, 14))
    if p.dist == "MEMBERS" then
        self.scopeBtn:SetText(("Members: %d"):format(#(p.members or {})))
    else
        self.scopeBtn:SetText("Scope: " .. (CHANNEL_LABELS[p.dist] or p.dist))
    end
    self.inviteBtn:SetEnabled(p.dist == "MEMBERS" and not viewing)
    if Portraits.Lockable(p) then
        self.lockBtn:Show()
        self.lockBtn:SetText(p.locked and "Unlock" or "Lock")
        self.lockBtn:SetEnabled(Portraits.IsOwner(p, me) and not viewing)
    else
        self.lockBtn:Hide()
    end
    self.clearBtn:SetEnabled(paintable)
    self.saveBtn:SetEnabled(not viewing)

    for id, btn in pairs(self.toolBtns) do
        btn:SetEnabled(paintable)
        if id == self.tool then
            btn:LockHighlight()
        else
            btn:UnlockHighlight()
        end
    end
    self.sizeBtn:SetText("Nib " .. (self.brushSize or 1))
    self.sizeBtn:SetEnabled(paintable)
    local canvasSize = self:CurrentSize()
    if self.visible and self.visible < canvasSize then
        self.zoomBtn:SetText(("%dpx %d/%d"):format(self.zoom, self.visible, canvasSize))
    else
        self.zoomBtn:SetText(("Zoom %dpx"):format(self.zoom or CELL))
    end
    self.undoBtn:SetEnabled(paintable and self:UndoIndex() ~= nil)
    if PP.db.showGrid then
        self.gridBtn:LockHighlight()
    else
        self.gridBtn:UnlockHighlight()
    end
end

function UI:UpdateTitle()
    if not self.title then
        return
    end
    if self.galleryView then
        self.title:SetText("Gallery: " .. self.galleryView.entry.name)
        return
    end
    local p = Portraits.Active()
    if p then
        self.title:SetText("Pixel Party - " .. p.name .. (p.locked and "  (locked)" or ""))
    end
end

function UI:UpdateAll()
    if not self.frame then
        return
    end
    self:LayoutViewport()
    self:UpdateTitle()
    self:UpdateButtons()
    self:UpdateStatus()
    self:UpdateGrid()
    self:RedrawAll()
    self:RefreshGallery()
    self:RefreshPicker()
    self:RefreshMembers()
end

function UI:Toggle()
    self:EnsureFrame()
    if self.frame:IsShown() then
        self.frame:Hide()
    else
        self.frame:Show()
    end
end

----------------------------------------------------------------------
-- Minimap button
----------------------------------------------------------------------

local MINIMAP_RADIUS = 80
-- WoW runs Lua 5.1 (math.atan2); the two-argument math.atan of 5.4 is the
-- same function, which keeps this file loadable off-client too.
local atan2 = math.atan2 or math.atan

function UI:PositionMinimapButton()
    local b = self.minimapBtn
    if not b then
        return
    end
    local angle = math.rad(PP.db.minimap.angle or 200)
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER",
        math.cos(angle) * MINIMAP_RADIUS, math.sin(angle) * MINIMAP_RADIUS)
end

local function DragUpdate()
    local mx, my = Minimap:GetCenter()
    if not mx then
        return
    end
    local scale = Minimap:GetEffectiveScale()
    local cx, cy = GetCursorPosition()
    PP.db.minimap.angle = math.deg(atan2(cy / scale - my, cx / scale - mx)) % 360
    UI:PositionMinimapButton()
end

function UI:EnsureMinimapButton()
    if self.minimapBtn or not Minimap then
        return
    end
    local b = CreateFrame("Button", "PixelPartyMinimapButton", Minimap)
    self.minimapBtn = b
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetMovable(true)

    -- The launcher uses a separately authored small-size glyph rather than a
    -- shrunken storefront logo. Keep Blizzard's tracking border around it.
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\AddOns\\PixelParty\\Media\\PixelPartyMinimap.tga")
    icon:SetSize(18, 18)
    icon:SetPoint("CENTER", b, "CENTER", 0, 1)

    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", DragUpdate)
        GameTooltip:Hide()
    end)
    b:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)
    b:SetScript("OnClick", function(_, button)
        UI:EnsureFrame()
        if button == "RightButton" then
            UI:TogglePicker()
        else
            UI:Toggle()
        end
    end)
    b:SetScript("OnEnter", function(self)
        local p = Portraits.Active()
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Pixel Party")
        if p then
            local sub
            if p.dist == "MEMBERS" then
                local n = #(p.members or {})
                sub = ("%d member%s"):format(n, n == 1 and "" or "s")
            else
                sub = "shared, " .. (CHANNEL_LABELS[p.dist] or p.dist)
            end
            GameTooltip:AddLine(("Painting '%s' (%s)%s"):format(p.name, sub,
                p.locked and "  |cffffcc00locked|r" or ""), 1, 1, 1, true)
        end
        GameTooltip:AddLine("Left-click: open the canvas", 0.6, 0.6, 0.6)
        GameTooltip:AddLine("Right-click: portraits, gallery, canvas", 0.6, 0.6, 0.6)
        GameTooltip:AddLine("Drag: move around the minimap", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    self:PositionMinimapButton()
    b:SetShown(not PP.db.minimap.hide)
end

function UI:ToggleMinimapButton()
    PP.db.minimap.hide = not PP.db.minimap.hide
    if self.minimapBtn then
        self.minimapBtn:SetShown(not PP.db.minimap.hide)
    end
    PP.Print(PP.db.minimap.hide
        and "Minimap button hidden - /pixelparty minimap brings it back."
        or "Minimap button shown.")
end
